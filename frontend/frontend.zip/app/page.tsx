'use client'

import { useEffect } from 'react'
import { useAppStore } from '@/lib/store'
import { PublicHeader } from '@/components/public/public-header'
import { PublicFooter } from '@/components/public/public-footer'
import { LandingPage } from '@/components/pages/landing-page'
import { ContestantsPage } from '@/components/pages/contestants-page'
import { ContestantDetailPage } from '@/components/pages/contestant-detail-page'
import { PaymentPage } from '@/components/pages/payment-page'
import { LeaderboardPage } from '@/components/pages/leaderboard-page'
import { AdminLoginPage } from '@/components/pages/admin-login-page'
import { AdminForgotPasswordPage } from '@/components/pages/admin-forgot-password-page'
import { AdminDashboardPage } from '@/components/pages/admin-dashboard-page'
import { AdminEventsPage } from '@/components/pages/admin-events-page'
import { AdminParticipantsPage } from '@/components/pages/admin-participants-page'
import { AdminPaymentsPage } from '@/components/pages/admin-payments-page'
import { AdminAdminsPage } from '@/components/pages/admin-admins-page'
import { AdminSettingsPage } from '@/components/pages/admin-settings-page'
import { AdminSocialRouterPage } from '@/components/pages/admin-social-router-page'
import type { ViewName } from '@/lib/types'

const publicViews = {
  landing: LandingPage,
  contestants: ContestantsPage,
  'contestant-detail': ContestantDetailPage,
  payment: PaymentPage,
  leaderboard: LeaderboardPage,
} as const

const adminAuthViews: Partial<Record<ViewName, React.ComponentType>> = {
  'admin-login': AdminLoginPage,
  'admin-forgot-password': AdminForgotPasswordPage,
}

const adminPanelViews: Partial<Record<ViewName, React.ComponentType>> = {
  'admin-dashboard': AdminDashboardPage,
  'admin-events': AdminEventsPage,
  'admin-participants': AdminParticipantsPage,
  'admin-payments': AdminPaymentsPage,
  'admin-admins': AdminAdminsPage,
  'admin-settings': AdminSettingsPage,
  'admin-social-router': AdminSocialRouterPage,
}

function isAdminAuthView(view: ViewName): boolean {
  return view === 'admin-login' || view === 'admin-forgot-password'
}

function isAdminPanelView(view: ViewName): boolean {
  return view in adminPanelViews
}

export default function Home() {
  const { currentView, isAdminLoggedIn, restoreSession } = useAppStore()

  // Restore auth session from localStorage on mount
  useEffect(() => {
    restoreSession()
  }, [restoreSession])

  // Public views
  const PublicComponent = publicViews[currentView as keyof typeof publicViews]
  if (PublicComponent) {
    return (
      <div className="flex min-h-screen flex-col">
        <PublicHeader />
        <main className="flex-1">
          <PublicComponent />
        </main>
        <PublicFooter />
      </div>
    )
  }

  // Admin auth views (login, forgot-password) — standalone, no shell
  if (isAdminAuthView(currentView)) {
    const AuthComponent = adminAuthViews[currentView]
    if (AuthComponent) {
      return <AuthComponent />
    }
  }

  // Admin panel views — require login
  if (isAdminPanelView(currentView)) {
    if (!isAdminLoggedIn) {
      const { navigate } = useAppStore.getState()
      navigate('admin-login')
      return null
    }
    const PanelComponent = adminPanelViews[currentView]
    if (PanelComponent) {
      return <PanelComponent />
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <PublicHeader />
      <main className="flex-1">
        <div className="flex min-h-[50vh] items-center justify-center">
          <p className="text-sm text-muted-foreground">Page not found.</p>
        </div>
      </main>
      <PublicFooter />
    </div>
  )
}
import { create } from "zustand"
import type { ViewName, ParticipantRecord, EventRecord } from "@/lib/types"
import { setAuthToken, getAuthToken } from "@/lib/api"

type AppStore = {
  // Navigation
  currentView: ViewName
  previousView: ViewName | null
  navigate: (view: ViewName) => void
  goBack: () => void

  // Selected contestant (for detail view)
  selectedParticipant: ParticipantRecord | null
  selectParticipant: (p: ParticipantRecord) => void

  // Selected event
  selectedEvent: EventRecord | null
  selectEvent: (e: EventRecord) => void

  // Public voting state
  isVotingUnlocked: boolean
  unlockVoting: () => void

  // Admin auth state
  isAdminLoggedIn: boolean
  authToken: string | null
  adminUser: { id: string; name: string; email: string; role: string } | null
  loginAdmin: (token: string, user: { id: string; name: string; email: string; role: string }) => void
  logoutAdmin: () => void
  restoreSession: () => void

  // Selected payment method
  selectedPaymentMethod: string | null
  setSelectedPaymentMethod: (id: string | null) => void

  // Category filter
  categoryFilter: string
  setCategoryFilter: (cat: string) => void
}

export const useAppStore = create<AppStore>((set, get) => ({
  // Navigation
  currentView: "landing",
  previousView: null,
  navigate: (view: ViewName) =>
    set((s) => ({ currentView: view, previousView: s.currentView })),
  goBack: () => {
    const prev = get().previousView
    if (prev) set((s) => ({ currentView: prev, previousView: s.previousView }))
  },

  // Contestant
  selectedParticipant: null,
  selectParticipant: (p) => set({ selectedParticipant: p }),

  // Event
  selectedEvent: null,
  selectEvent: (e) => set({ selectedEvent: e }),

  // Voting
  isVotingUnlocked: false,
  unlockVoting: () => set({ isVotingUnlocked: true }),

  // Admin auth
  isAdminLoggedIn: false,
  authToken: null,
  adminUser: null,
  loginAdmin: (token, user) => {
    setAuthToken(token)
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('vw_token', token)
      localStorage.setItem('vw_user', JSON.stringify(user))
    }
    set({ isAdminLoggedIn: true, authToken: token, adminUser: user })
  },
  logoutAdmin: () => {
    setAuthToken(null)
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem('vw_token')
      localStorage.removeItem('vw_user')
    }
    set({
      isAdminLoggedIn: false,
      authToken: null,
      adminUser: null,
      currentView: "landing" as ViewName,
    })
  },
  restoreSession: () => {
    if (typeof localStorage === 'undefined') return
    const token = localStorage.getItem('vw_token')
    const userStr = localStorage.getItem('vw_user')
    if (token && userStr) {
      try {
        const user = JSON.parse(userStr)
        setAuthToken(token)
        set({ isAdminLoggedIn: true, authToken: token, adminUser: user })
      } catch {
        localStorage.removeItem('vw_token')
        localStorage.removeItem('vw_user')
      }
    }
  },

  // Payment method
  selectedPaymentMethod: null,
  setSelectedPaymentMethod: (id) => set({ selectedPaymentMethod: id }),

  // Category filter
  categoryFilter: "All",
  setCategoryFilter: (cat) => set({ categoryFilter: cat }),
}))
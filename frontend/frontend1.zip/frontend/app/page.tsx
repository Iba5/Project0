'use client'

export const dynamic = 'force-dynamic'

import { Suspense, useEffect, useMemo } from 'react'
import { AnimatePresence } from 'framer-motion'
import { usePathname, useSearchParams } from 'next/navigation'
import { useAppStore } from '@/lib/store'
import { getMe } from '@/lib/api'
import { PageTransition, type TransitionVariant } from '@/components/shared/page-transition'

// Public views
import LandingView from '@/components/views/landing-view'
import ContestantsView from '@/components/views/contestants-view'
import ContestantDetailView from '@/components/views/contestant-detail-view'
import LeaderboardView from '@/components/views/leaderboard-view'
import EventsView from '@/components/views/events-view'
import PaymentView from '@/components/views/payment-view'
import CompareView from '@/components/views/compare-view'

// Admin views
import { AdminLoginView } from '@/components/views/admin-login-view'
import { AdminDashboardView } from '@/components/views/admin-dashboard-view'
import { AdminEventsView } from '@/components/views/admin-events-view'
import { AdminParticipantsView } from '@/components/views/admin-participants-view'
import { AdminPaymentsView } from '@/components/views/admin-payments-view'
import { AdminSettingsView } from '@/components/views/admin-settings-view'
import { AdminAdminsView } from '@/components/views/admin-admins-view'
import { AdminSocialRouterView } from '@/components/views/admin-social-router-view'
import { AdminAuditView } from '@/components/views/admin-audit-view'
import { AdminForgotPasswordView } from '@/components/views/admin-forgot-password-view'

// Layout
import { PublicHeader } from '@/components/public/public-header'
import { PublicFooter } from '@/components/public/public-footer'
import { AdminShell } from '@/components/admin/admin-shell'

function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="layout-sticky-footer" style={{ background: '#0B0F17' }}>
      <PublicHeader />
      <main className="flex-1 pb-16 md:pb-0">{children}</main>
      <PublicFooter />
    </div>
  )
}

function PublicRouter() {
  const { currentView } = useAppStore()
  const transitionVariant: TransitionVariant = 'slideUp'

  const publicViews: Record<string, React.ReactNode> = {
    'landing': <LandingView />,
    'contestants': <ContestantsView />,
    'contestant-detail': <ContestantDetailView />,
    'leaderboard': <LeaderboardView />,
    'events': <EventsView />,
    'payment': <PaymentView />,
    'compare': <CompareView />,
  }

  // Fallback cleanly to LandingView if key is unknown
  const viewContent = publicViews[currentView] ?? <LandingView />

  return (
    <PublicLayout>
      <AnimatePresence mode="wait">
        <PageTransition key={currentView} variant={transitionVariant} duration={0.35}>
          <div className="page-transition">
            {viewContent}
          </div>
        </PageTransition>
      </AnimatePresence>
    </PublicLayout>
  )
}

function AdminRouter() {
  const { currentView, adminUser, setAdminUser, setView } = useAppStore()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  const resetState = useMemo(() => ({
    token: searchParams?.get('token') || '',
    email: searchParams?.get('email') || '',
  }), [searchParams])

  useEffect(() => {
    if (pathname === '/reset-password' && currentView !== 'admin-forgot-password') {
      setView('admin-forgot-password')
    }
  }, [pathname, currentView, setView])

  useEffect(() => {
    if (!adminUser) {
      getMe()
        .then(({ user }: { user: { id: string; name: string; email: string; role: string } }) => {
          setAdminUser(user)
          setView('admin-dashboard')
        })
        .catch(() => {
          // Unauthenticated
        })
    }
  }, [adminUser, setAdminUser, setView])

  if (!adminUser && currentView !== 'admin-forgot-password') {
    return <AdminLoginView />
  }

  if (currentView === 'admin-forgot-password') {
    return <AdminForgotPasswordView initialToken={resetState.token} initialEmail={resetState.email} />
  }

  const viewMap: Record<string, React.ReactNode> = {
    'admin-dashboard': <AdminDashboardView />,
    'admin-events': <AdminEventsView />,
    'admin-participants': <AdminParticipantsView />,
    'admin-payments': <AdminPaymentsView />,
    'admin-settings': <AdminSettingsView />,
    'admin-admins': <AdminAdminsView />,
    'admin-social-router': <AdminSocialRouterView />,
    'admin-audit': <AdminAuditView />,
  }

  // Fallback cleanly to AdminDashboardView if key is unknown
  const viewContent = viewMap[currentView] ?? <AdminDashboardView />

  return <AdminShell>{viewContent}</AdminShell>
}
export default function Home() {
  const { currentView } = useAppStore()

  // Determine if we're in admin view or public view
  const isAdminView = currentView.startsWith('admin-')

  if (isAdminView) {
    return (
      <Suspense fallback={<div>Loading...</div>}>
        <AdminRouter />
      </Suspense>
    )
  }

  return <PublicRouter />
}

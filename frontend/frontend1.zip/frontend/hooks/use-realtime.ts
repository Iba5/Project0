'use client'

import { useEffect, useRef, useCallback } from 'react'
import { io, Socket } from 'socket.io-client'
import { getApiBaseUrl } from '@/lib/api-client'

export interface VoteUpdateData {
  participantId: string
  votes: number
  participantName: string
  timestamp: number
}

/** Payload broadcast to every client on each vote. */
export interface VoteGlobalData {
  participantId: string
  participantName: string
  category: string
  votesDelta: number
  totalVotes: number
  timestamp: number
}

/** Payload broadcast when a participant crosses a vote threshold. */
export interface VoteMilestoneData {
  participantId: string
  participantName: string
  totalVotes: number
  milestone: number
}

/** Replay payload sent to a client once, immediately after connect. */
export type VoteRecentData = VoteGlobalData[]

export function useRealtime() {
  const socketRef = useRef<Socket | null>(null)

  useEffect(() => {
    // Extract base origin (e.g. "http://localhost:8000") without any path suffix like "/api/v1"
    const rawApiUrl = getApiBaseUrl()
    let socketOrigin = rawApiUrl

    try {
      const urlObj = new URL(rawApiUrl)
      socketOrigin = urlObj.origin
    } catch {
      // Fallback if rawApiUrl is relative or invalid
      socketOrigin = typeof window !== 'undefined' ? window.location.origin : 'http://localhost:8000'
    }

    // Connect to the FastAPI backend's WebSocket server root
    const socket = io(socketOrigin, {
      path: '/socket.io', // Standard Socket.io server path
      transports: ['polling', 'websocket'], // Try polling handshake first, then upgrade
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 10000,
      withCredentials: true,
    })

    socket.on('connect', () => {
      console.log('[Realtime] Connected:', socket.id)
    })

    socket.on('disconnect', (reason) => {
      console.log('[Realtime] Disconnected:', reason)
    })

    socket.on('connect_error', (error) => {
      console.warn('[Realtime] Connection error details:', error.message, error)
    })

    socketRef.current = socket

    return () => {
      socket.disconnect()
      socketRef.current = null
    }
  }, [])

  const joinParticipant = useCallback((participantId: string) => {
    if (socketRef.current?.connected) {
      socketRef.current.emit('join:participant', participantId)
    } else {
      // Wait for connection then join
      socketRef.current?.once('connect', () => {
        socketRef.current?.emit('join:participant', participantId)
      })
    }
  }, [])

  const leaveParticipant = useCallback((participantId: string) => {
    socketRef.current?.emit('leave:participant', participantId)
  }, [])

  const onVoteUpdate = useCallback(
    (callback: (data: VoteUpdateData) => void) => {
      socketRef.current?.on('vote:update', callback)
      return () => {
        socketRef.current?.off('vote:update', callback)
      }
    },
    [],
  )

  const onLeaderboardUpdate = useCallback(
    (callback: (data: VoteUpdateData) => void) => {
      socketRef.current?.on('leaderboard:update', callback)
      return () => {
        socketRef.current?.off('leaderboard:update', callback)
      }
    },
    [],
  )

  /** Listen for global vote events. Fired on every vote. */
  const onVoteGlobal = useCallback(
    (callback: (data: VoteGlobalData) => void) => {
      socketRef.current?.on('vote:global', callback)
      return () => {
        socketRef.current?.off('vote:global', callback)
      }
    },
    [],
  )

  /** Listen for milestone events. Fired when a participant crosses
   * a 500/1000/2500/5000/10000 vote boundary. */
  const onVoteMilestone = useCallback(
    (callback: (data: VoteMilestoneData) => void) => {
      socketRef.current?.on('vote:milestone', callback)
      return () => {
        socketRef.current?.off('vote:milestone', callback)
      }
    },
    [],
  )

  /** Listen for the recent-votes replay. Fired once on connect. */
  const onVoteRecent = useCallback(
    (callback: (data: VoteRecentData) => void) => {
      socketRef.current?.on('vote:recent', callback)
      return () => {
        socketRef.current?.off('vote:recent', callback)
      }
    },
    [],
  )

  return {
    joinParticipant,
    leaveParticipant,
    onVoteUpdate,
    onLeaderboardUpdate,
    onVoteGlobal,
    onVoteMilestone,
    onVoteRecent,
  }
}
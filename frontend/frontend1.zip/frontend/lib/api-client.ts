/**
 * Centralized API client for the FastAPI backend.
 *
 * All API calls go through this module so the backend URL is configured
 * in one place. Set NEXT_PUBLIC_API_URL in your .env.local to point
 * to your FastAPI server (e.g. http://localhost:8000).
 *
 * If the variable is not set, it defaults to http://localhost:8000.
 */

const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_URL || process.env.BACKEND_API_URL || 'http://localhost:8000/api/v1'

const TOKEN_KEY = 'voting_admin_token'

/**
 * Get the stored JWT token from localStorage.
 */
export function getStoredToken(): string | null {
  if (typeof window === 'undefined') return null
  return localStorage.getItem(TOKEN_KEY)
}

/**
 * Store the JWT token in localStorage.
 */
export function storeToken(token: string): void {
  if (typeof window === 'undefined') return
  localStorage.setItem(TOKEN_KEY, token)
}

/**
 * Clear the stored JWT token from localStorage.
 */
export function clearToken(): void {
  if (typeof window === 'undefined') return
  localStorage.removeItem(TOKEN_KEY)
}

/**
 * Build a full URL for a FastAPI endpoint.
 * Example: apiUrl('/auth/login') → 'http://localhost:8000/api/v1/auth/login'
 * 
 * Automatically appends trailing slashes for collection endpoints that require them.
 */
export function apiUrl(path: string): string {
  // Ensure the path starts with /
  let normalized = path.startsWith('/') ? path : `/${path}`
  
  // List of collection endpoints that require trailing slashes
  const collectionEndpoints = [
    '/events',
    '/participants',
    '/dashboard',
    '/settings',
    '/admins',
    '/audit-logs',
    '/social-router',
  ]
  
  // Add trailing slash for collection endpoints if not already present
  for (const endpoint of collectionEndpoints) {
    if (normalized === endpoint) {
      normalized = endpoint + '/'
      break
    }
  }
  
  return `${API_BASE_URL}${normalized}`
}

/**
 * Get the base API URL (useful for WebSocket connections, etc.)
 */
export function getApiBaseUrl(): string {
  return API_BASE_URL
}

/**
 * Convenience fetch wrapper that automatically prepends the FastAPI base URL.
 * Handles JSON responses and throws on non-OK status codes.
 * Automatically includes the JWT Authorization header if available.
 */
export async function apiFetch<T = unknown>(
  path: string,
  options?: RequestInit,
): Promise<T> {
  const headers = new Headers(options?.headers || {})
  
  // Add JSON content type if not present
  if (!headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }
  
  // Add Authorization header with stored token if available
  const token = getStoredToken()
  if (token) {
    headers.set('Authorization', `Bearer ${token}`)
  }
  
  const res = await fetch(apiUrl(path), {
    ...options,
    headers,
  })

  const data = await res.json()

  if (!res.ok) {
    throw new Error(data?.detail || data?.error || data?.message || `Request failed with status ${res.status}`)
  }

  return data as T
}

/**
 * Upload a file to the FastAPI backend (multipart/form-data).
 */
export async function apiUpload<T = unknown>(
  path: string,
  formData: FormData,
): Promise<T> {
  const headers = new Headers()
  
  // Add Authorization header with stored token if available
  const token = getStoredToken()
  if (token) {
    headers.set('Authorization', `Bearer ${token}`)
  }
  
  const res = await fetch(apiUrl(path), {
    method: 'POST',
    body: formData,
    headers,
    // Do NOT set Content-Type — browser sets it with boundary for FormData
  })

  const data = await res.json()

  if (!res.ok) {
    throw new Error(data?.detail || data?.error || data?.message || `Upload failed with status ${res.status}`)
  }

  return data as T
}

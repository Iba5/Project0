import { create } from 'zustand'

export type ViewName =
  | 'landing'
  | 'contestants'
  | 'contestant-detail'
  | 'leaderboard'
  | 'events'
  | 'payment'
  | 'compare'
  | 'admin-login'
  | 'admin-dashboard'
  | 'admin-events'
  | 'admin-participants'
  | 'admin-payments'
  | 'admin-settings'
  | 'admin-admins'
  | 'admin-social-router'
  | 'admin-audit'
  | 'admin-forgot-password'
  | 'notifications'

export type AdminUser = {
  id: string
  name: string
  email: string
  role: string
}

type AppStore = {
  currentView: ViewName
  setView: (view: ViewName) => void

  selectedParticipantId: string | null
  setSelectedParticipantId: (id: string | null) => void

  selectedEventId: string | null
  setSelectedEventId: (id: string | null) => void

  selectedPaymentMethod: string | null
  setSelectedPaymentMethod: (id: string | null) => void

  categoryFilter: string
  setCategoryFilter: (cat: string) => void

  eventFilter: string
  setEventFilter: (filter: string) => void

  adminUser: AdminUser | null
  setAdminUser: (user: AppStore['adminUser']) => void

  paymentParticipantId: string | null
  setPaymentParticipantId: (id: string | null) => void

  compareIds: string[]
  setCompareIds: (ids: string[]) => void

  // Global search state (Task 11-C)
  searchQuery: string
  setSearchQuery: (q: string) => void
  isSearchOpen: boolean
  setSearchOpen: (open: boolean) => void
}

export const useAppStore = create<AppStore>((set, _get) => ({
  currentView: 'landing',
  setView: (view) => set({ currentView: view }),

  selectedParticipantId: null,
  setSelectedParticipantId: (id) => set({ selectedParticipantId: id }),

  selectedEventId: null,
  setSelectedEventId: (id) => set({ selectedEventId: id }),

  selectedPaymentMethod: null,
  setSelectedPaymentMethod: (id) => set({ selectedPaymentMethod: id }),

  categoryFilter: 'All',
  setCategoryFilter: (cat) => set({ categoryFilter: cat }),

  eventFilter: 'All',
  setEventFilter: (filter) => set({ eventFilter: filter }),

  adminUser: null,
  setAdminUser: (user) => set({ adminUser: user }),

  paymentParticipantId: null,
  setPaymentParticipantId: (id) => set({ paymentParticipantId: id }),

  compareIds: [],
  setCompareIds: (ids) => set({ compareIds: ids }),

  searchQuery: '',
  setSearchQuery: (q) => set({ searchQuery: q }),

  isSearchOpen: false,
  setSearchOpen: (open) => set({ isSearchOpen: open }),
}))
